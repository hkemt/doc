package emt.emt.grant.dao;

import emt.emt.common.domain.User;

public interface GrantDao {
	public int grantAuth(User user);
}
