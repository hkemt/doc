package emt.emt.login.service;

import emt.emt.common.domain.User;

public interface LoginService {
	User loginCheck(User user);
}
