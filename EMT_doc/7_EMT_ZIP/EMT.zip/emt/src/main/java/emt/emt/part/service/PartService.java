package emt.emt.part.service;

import java.util.List;

import emt.emt.common.domain.Question;

public interface PartService {

	List<Question> partQuestion(Question question);
}
