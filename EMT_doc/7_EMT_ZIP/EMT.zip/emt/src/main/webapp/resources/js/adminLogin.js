function admin(){
	location.replace("/emt/admin/adminMain");
}