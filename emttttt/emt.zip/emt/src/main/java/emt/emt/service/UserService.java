package emt.emt.service;

import java.util.List;

import emt.emt.domain.User;

public interface UserService {
	User loginCheck(User user);
}
