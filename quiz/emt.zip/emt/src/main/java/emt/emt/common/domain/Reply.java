package emt.emt.common.domain;

import java.sql.Date;

public class Reply {
	
/*
  	REPLY_NO		NUMBER
	USER_ID			VARCHAR2(20 BYTE)
	REPLY_CONTENT	VARCHAR2(4000 BYTE)
	BOARD_NO		NUMBER
	REPLY_DATE		DATE
*/
	
	private int replyNo;
	private String userId;
	private String replyContent;
	private int boardNo;
	private Date replyDate;
	
	
	

}
