$.ajax({
	type : 'POST',
	url : "finish.php",
	dataType : 'json',

	success : function(currentscore) {
		document.getElementById('resultscore').innerHTML = currentscore + "/" + (localStorage.getItem('maxcount')-1);
		
		percent = currentscore / (localStorage.getItem('maxcount')-1) * 100;
		document.getElementById('pg').style.width= percent+"%";
		document.getElementById('pg').innerHTML = percent + "%";
	}
})

function tofirst() {
	location.replace('wtselectlevel.php');
}

function getout() {
	location.replace('quizselect.php');
}


