<?php
include '../../dbconn/db_info.php';

$id = $_SESSION['user_id'];
$sql = "select user_num from user where user_id='".$id."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$usernum = htmlentities($row['user_num']);

$sql = "select word_lev from userselectlev where user_num='".$usernum."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$level = htmlentities($row['word_lev']);

$sql = "select currentscore from score where user_num = '".$usernum."' and word_lev='".$level."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$currentscore = htmlentities($row['currentscore']);

echo urldecode($currentscore);

?>