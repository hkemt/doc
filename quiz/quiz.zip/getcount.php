<?php
include "../../dbconn/db_info.php";

$count = $_POST['variable1'];

if($count == 1) {
	$sql = "update count set count = 0;";
	mysqli_query($conn, $sql);
}

?>