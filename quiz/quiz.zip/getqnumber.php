<?php
include "../../dbconn/db_info.php";

$qnum = $_POST['variable1'];
$count = $_POST['variable2'];

$id = $_SESSION['user_id'];
$sql = "select user_num from user where user_id='".$id."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$usernum = htmlentities($row['user_num']);

if ($count == 1) {
	$sql = "update qnum set qnumstring = '' where user_num = '".$usernum."';";
	mysqli_query($conn, $sql);
}

$sql = "select qnumstring from qnum where user_num = '".$usernum."';";
$result = $conn -> query($sql);
while ($row = $result -> fetch_assoc()) {
	$qnumarr = $row["qnumstring"];
}

$qnumarr = $qnumarr . "," . $qnum;

$sql = "update qnum set qnumstring = '" . $qnumarr . "' where user_num = '".$usernum."';";
mysqli_query($conn, $sql);

?>