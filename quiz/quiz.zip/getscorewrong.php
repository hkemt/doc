<?php
include '../../dbconn/db_info.php';

$id = $_SESSION['user_id'];
$sql = "select user_num from user where user_id='".$id."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$usernum = htmlentities($row['user_num']);

$sql = "select word_lev from userselectlev where user_num=".$usernum.";";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$level = htmlentities($row['word_lev']);

$score = $_POST['variable1'];
$wrong = $_POST['variable2'];

$sql = "update score set currentscore = '" . $score . "' where user_num = ".$usernum." and word_lev='".$level."';";
mysqli_query($conn, $sql);

$sql = "select highscore from score where user_num = ".$usernum." and word_lev='".$level."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$highscore = htmlentities($row['highscore']);

if ($score > $highscore) {
	$sql = "update score set highscore = '" . $score . "' where user_num = ".$usernum." and word_lev='".$level."';";
	mysqli_query($conn, $sql);
}

$sql = "select wrongstring from wrong where user_num = ".$usernum." and word_lev='".$level."';";
$result = $conn -> query($sql);
while ($row = $result -> fetch_assoc()) {
	$wrongstring = $row['wrongstring'];
}

$pieces = explode(",", $wrong);

$numstring = '';

for ($i = 0; $i < count($pieces); $i++) {
	$sql = "select word_num from word where word_chi = '" . $pieces[$i] . "' and word_lev='".$level."';";
	$result = $conn -> query($sql);
	while ($row = $result -> fetch_assoc()) {
		$numstring = $numstring . "," . $row['word_num'];
	}
}

$wrongstring = $wrongstring . $numstring;

$numpieces = explode(",", $wrongstring);
array_shift($numpieces);
$uniquearray = array_unique($numpieces);

$finalarray = [];

foreach ($uniquearray as $value) {
	array_push($finalarray, $value);
}

//sort($finalarray);

$finalstring = '';

for ($i = 0; $i < count($finalarray); $i++) {
	$finalstring = $finalstring . "," . $finalarray[$i];
}

$sql = "update wrong set wrongstring = '" . $finalstring . "' where user_num = ".$usernum." and word_lev='".$level."';";
mysqli_query($conn, $sql);
?>
