<?php
include "../../dbconn/db_info.php";

$id = $_SESSION['user_id'];
$sql = "select user_num from user where user_id='".$id."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$usernum = htmlentities($row['user_num']);

$sql = "select word_lev from userselectlev where user_num='".$usernum."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$level = htmlentities($row['word_lev']);

$sql = "select qnumstring from qnum where user_num = '".$usernum."';";
$result = $conn -> query($sql);
while ($row = $result -> fetch_assoc()) {
	$qstring = $row["qnumstring"];
}

$numpieces = explode(",", $qstring);

array_shift($numpieces);

$arrnum = $numpieces;

$arrnum1 = [];

foreach ($arrnum as $value) {
	array_push($arrnum1, $value);
}

$notin = '';

for ($i = 0; $i < count($arrnum1); $i++) {
	if ($i == (count($arrnum1) - 1)) {
		$notin = $notin . $arrnum1[$i];
	} else {
		$notin = $notin . $arrnum1[$i] . ",";
	}
}

if ($notin == '' || ($level == '7급' and strlen($notin) == 59) || ($level == '6급' and strlen($notin) == 59)) {
	$sql = "select word_num from word where word_lev = '" . $level . "';";
	$result = $conn -> query($sql);
	$i = 0;
	while ($row = $result -> fetch_array(MYSQLI_ASSOC)) {
		$questionnum[$i] = $row["word_num"];
		$i++;
	}
} else {$sql = "select word_num from word where word_num not in(" . $notin . ") and word_lev = '" . $level . "';";
	$result = $conn -> query($sql);
	$i = 0;
	while ($row = $result -> fetch_array(MYSQLI_ASSOC)) {
		$questionnum[$i] = $row["word_num"];
		$i++;
	}
}

function array_random($arr, $num = 1) {
	shuffle($arr);

	$r = array();
	for ($i = 0; $i < $num; $i++) {
		$r[] = $arr[$i];
	}
	return $num == 1 ? $r[0] : $r;
}

$qnum = array_random($questionnum);

$sql = "select word_chi from word where word_num = '" . $qnum . "'and word_lev = '" . $level . "';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$question = htmlentities($row['word_chi']);

$sql = "select word_kor from word where word_num = '" . $qnum . "'and word_lev = '" . $level . "';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$answer = htmlentities($row['word_kor']);

$sql = "select word_num from word where word_num not in(" . $qnum . ") and word_lev = '" . $level . "';";
$result = $conn -> query($sql);

$i = 0;
while ($row = $result -> fetch_array(MYSQLI_ASSOC)) {
	$data[$i] = $row["word_num"];
	$i++;
}

$rand_keys = array_rand($data, 3);

for ($i = 0; $i < 3; $i++) {
	$answer4[$i] = $data[$rand_keys[$i]];
}

$answer4[3] = $qnum;

shuffle($answer4);

for ($i = 0; $i < 4; $i++) {
	$sql = "select word_kor from word where word_num = '" . $answer4[$i] . "' and word_lev = '" . $level . "';";
	$result = $conn -> query($sql);
	$row = $result -> fetch_assoc();
	$answer4[$i] = htmlentities($row['word_kor']);
}

$quiz = array($question, $answer4[0], $answer4[1], $answer4[2], $answer4[3], $answer, $qnum, $level);

$output = $quiz;
$stringJSON = json_encode($output, JSON_UNESCAPED_UNICODE);
echo urldecode($stringJSON);

return $qnum;
?>