<!-- client 공통 부분(1.html앞부분, 2.main_nav스위칭부분, 3. menu_nav부분 4. 세션정보 확인부분 포함 (시작) -->
<?php include $_SERVER ['DOCUMENT_ROOT'] . "//include/common_top.php";?>

<!-- Custom styles for this template -->
<link href="/main.css" rel="stylesheet">

<title>Wrong Finish</title>
</head>
<body>
	<header class="header-wrapper">
		<div class="container" id="main_nav1" style="display:"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/main_nav1.php";?></div>
		<div class="container" id="main_nav2" style="display: none"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/main_nav2.php";?></div>
		<?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/session_login.php";?>
		<div class="container" id="menu_nav"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/menu_nav.php";?></div>
	</header>
<!-- client 공통 부분(1.html앞부분, 2.main_nav스위칭부분, 3. menu_nav부분 4. 세션정보 확인부분 포함 (끝) -->

	<div class='container'>
		<div class="alert alert-success" role="alert">
			<strong>틀린 문제가 더 이상 없습니다.</strong>
		</div>
	</div>
	</body>
</html>