<!-- client 공통 부분(1.html앞부분, 2.main_nav스위칭부분, 3. menu_nav부분 4. 세션정보 확인부분 포함 (시작) -->
<?php include $_SERVER ['DOCUMENT_ROOT'] . "//include/common_top.php";?>

<!-- Custom styles for this template -->
<link href="/main.css" rel="stylesheet">
<link href="mycss.css" rel="stylesheet">
<link href="grid.css" rel="stylesheet">
<script type="text/javascript" src="jquery-1.11.2.js"></script>
<script type="text/javascript" src="quizscript.js"></script>

<title>Quiz</title>
</head>
<body>
	<header class="header-wrapper">
		<div class="container" id="main_nav1" style="display:"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/main_nav1.php";?></div>
		<div class="container" id="main_nav2" style="display: none"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/main_nav2.php";?></div>
		<?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/session_login.php";?>
		<div class="container" id="menu_nav"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/menu_nav.php";?></div>
	</header>
<!-- client 공통 부분(1.html앞부분, 2.main_nav스위칭부분, 3. menu_nav부분 4. 세션정보 확인부분 포함 (끝) -->

	<div class='container firstline'>
		<div class="col-xs-4">
			<span id='questionNum' class="badge"></span>
		</div>
		<div class="col-xs-4">
			점수 <span id='score' class="badge"></span>
		</div>
		
		<div class="col-xs-4">
			<span id='correct' class="badge">확인</span>
		</div>
	</div>
	
	<div class='container'>
		<div class="jumbotron bigbox">
			<span id='time' class="badge"></span>
			<div class='question' name='button'>
				오류
			</div>

			<div class='buttongroup'>
				<button type="button" class="btn btn-default ansbtn" name='button' onclick=correct(this)></button>
				<br />
				<br />
				<button type="button" class="btn btn-default ansbtn" name='button' onclick=correct(this)></button>
				<br />
				<br />
				<button type="button" class="btn btn-default ansbtn" name='button' onclick=correct(this)></button>
				<br />
				<br />
				<button type="button" class="btn btn-default ansbtn" name='button' onclick=correct(this)></button>
				<br />
				<br />
			</div>

			<br />
			<button type="button" class="btn btn-default tofirst" onclick="tofirst()">
				처음부터
			</button>
			<button type="button" class="btn btn-default out" onclick="getout()">
				나가기
			</button>
		</div>
	</div>
	</body>
	</html>