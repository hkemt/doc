var count = 0;
var score = 0;
var wrong = [];
var j = 0;
var n = 5;

getquestionarray(false);

var tm = setInterval(function() {
	getquestionarray(true)
}, 5000);

var tm2 = setInterval(countDown, 1000);

function passqnum(arg) {
	return $.ajax({
		type : "POST",
		url : "getqnumber.php",
		data : "variable1=" + arg + "\u0026variable2=" + count,
		success : function() {
		}
	});
}

function getquestionarray(flagarg) {
	if (flagarg == true) {
		wrong[j] = document.getElementsByName("button")[0].innerHTML;
		j++;
		//document.getElementById('wrong').value = wrong;
		document.getElementById('correct').innerHTML = '오답';
		document.getElementById('correct').style.background = 'red';
	}
	count++;

	if (count == localStorage.getItem('maxcount')) {
		passcorewrong();
		location.replace('finish1.php');
	}

	return $.ajax({
		type : 'POST',
		url : "makeonequestion.php",
		dataType : 'json',

		success : function(a) {
			answer = a[5];

			qnum = a[6];

			passqnum(qnum);
			
			level = a[7];
			
			localStorage.setItem("maxcount", 0);
			
			if(level=='8급' || level=='7급' || level=='6급') {
				localStorage['maxcount'] = 21;
			}
			
			if(level == '준5급' || level=='5급' || level=='준4급' || level=='4급' || level=='준3급' || level=='3급') {
				localStorage['maxcount'] = 41;
			}
			
			if(level== '2급' || level=='1급' || level=='특급') {
				localStorage['maxcount'] = 91;
			}
			
			for (var i = 0; i < 5; i++) {
				document.getElementsByName("button")[i].innerHTML = a[i];
			}
			document.getElementById('questionNum').innerHTML = count + "/" + (localStorage.getItem('maxcount')-1);
			document.getElementById('score').innerHTML = score;
			document.getElementById('time').innerHTML = 5;
		}
	});
}

function correct(objButton) {
	clearInterval(tm);

	tm = setInterval(function() {
		getquestionarray(true)
	}, 5000);

	n = 7;

	countDown();

	if (objButton.innerHTML == answer) {
		document.getElementById('correct').innerHTML = '정답';
		document.getElementById('correct').style.background = 'blue'; ++score;
		if (count == localStorage.getItem('maxcount')) {
			passcorewrong();
			location.replace('finish1.php');
		} else {
			getquestionarray(false);
		}
	} else {
		document.getElementById('correct').innerHTML = '오답';
		document.getElementById('correct').style.background = 'red';
		wrong[j] = document.getElementsByName("button")[0].innerHTML;
		j++;
		//document.getElementById('wrong').value = wrong;
		if (count == localStorage.getItem('maxcount')) {
			passcorewrong();
			location.replace('finish1.php');
		} else {
			getquestionarray(false);
		}
	}
	document.getElementById('questionNum').innerHTML = count;
	document.getElementById('score').innerHTML = score;
}

function countDown() {--n;
	if (n == 0) {
		n = 5;
	}
	document.getElementById('time').innerHTML = n;
}

function passcorewrong() {
	$.ajax({
		type : "POST",
		url : "getscorewrong.php",
		data : "variable1=" + score + "\u0026variable2=" + wrong,
		success : function() {

		}
	});
}

function tofirst() {
	location.replace('quiz.php');
}

function getout() {
	location.replace('quizselect.php');
}
