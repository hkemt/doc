<!-- client 공통 부분(1.html앞부분, 2.main_nav스위칭부분, 3. menu_nav부분 4. 세션정보 확인부분 포함 (시작) -->
<?php include $_SERVER ['DOCUMENT_ROOT'] . "//include/common_top.php";?>

<!-- Custom styles for this template -->
<link href="/main.css" rel="stylesheet">
<script type="text/javascript" src="jquery-1.11.2.js"></script>
<script type="text/javascript" src="selectlev.js"></script>

<title>Quiz Select</title>
</head>
<body>
	<header class="header-wrapper">
		<div class="container" id="main_nav1" style="display:"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/main_nav1.php";?></div>
		<div class="container" id="main_nav2" style="display: none"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/main_nav2.php";?></div>
		<?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/session_login.php";?>
		<div class="container" id="menu_nav"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/menu_nav.php";?></div>
	</header>
<!-- client 공통 부분(1.html앞부분, 2.main_nav스위칭부분, 3. menu_nav부분 4. 세션정보 확인부분 포함 (끝) -->
<div class="container" style="margin-top: 30px">
		<div align="center">
			<div style="margin-top: 30px" class="btn-group">
				<button style="width: 280px; height: 100px" type="button"
				class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
					4지선다 퀴즈<span class="caret"></span>
				</button>
				<ul class="dropdown-menu" role="menu">
					<li>
						<a href="quiz.php" onclick="return link(this)">8급</a>
					</li>
					<li>
						<a href="quiz.php" onclick="return link(this)">7급</a>
					</li>
					<li>
						<a href="quiz.php" onclick="return link(this)">6급</a>
					</li>
					<li class="divider"></li>
					<li>
						<a href="quiz.php" onclick="return link(this)">준5급</a>
					</li>
					<li>
						<a href="quiz.php" onclick="return link(this)">5급</a>
					</li>
					<li class="divider"></li>
					<li>
						<a href="quiz.php" onclick="return link(this)">준4급</a>
					</li>
					<li>
						<a href="quiz.php" onclick="return link(this)">4급</a>
					</li>
					<li class="divider"></li>
					<li>
						<a href="quiz.php" onclick="return link(this)">준3급</a>
					</li>
					<li>
						<a href="quiz.php" onclick="return link(this)">3급</a>
					</li>
					<li class="divider"></li>
					<li>
						<a href="quiz.php" onclick="return link(this)">2급</a>
					</li>
					<li>
						<a href="quiz.php" onclick="return link(this)">1급</a>
					</li>
					<li>
						<a href="quiz.php" onclick="return link(this)"">특급</a>
					</li>
				</ul>
			</div>

		</div>
	</div>
	
	<script
		src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="/bootstrap/js/bootstrap.min.js"></script>
	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<script src="/bootstrap/js/ie10-viewport-bug-workaround.js"></script>
	<script src="/bootstrap/dist/js/bootstrap.min.js"></script>
	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<script src="/bootstrap/assets/js/ie10-viewport-bug-workaround.js"></script>

	<script>	
		$(document).ready(function() {
			$('.dropdown-toggle').dropdown();
		});
	</script>
	</body>
	</html>