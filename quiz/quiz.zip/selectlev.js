function link(Object) {
	$.ajax({
		type : "POST",
		url : "selectlev.php",
		data : "variable1=" + Object.innerHTML,
		success : function() {
		}
	});

}
