<?php
include '../../dbconn/db_info.php';

$id = $_SESSION['user_id'];
$sql = "select user_num from user where user_id='" . $id . "';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$usernum = htmlentities($row['user_num']);

$level = $_POST['variable1'];

$sql = "insert into qnum (user_num) values (" . $usernum . ");";
mysqli_query($conn, $sql);

$sql = "insert into count (user_num) values (" . $usernum . ");";
mysqli_query($conn, $sql);

$sql = "insert into userselectlev (user_num) values (" . $usernum . ");";
mysqli_query($conn, $sql);

$sql = "update userselectlev set word_lev='" . $level . "' where user_num='" . $usernum . "';";
mysqli_query($conn, $sql);

$sql = "insert into score (user_num, word_lev, currentscore) values (" . $usernum . ", '" . $level . "', 0);";
mysqli_query($conn, $sql);

$sql = "insert into wrong (user_num, word_lev) values (" . $usernum . ", '" . $level . "');";
mysqli_query($conn, $sql);
?>