<html>
	<head>
		<title>Quiz Select Level</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<script type="text/javascript" src="jquery-1.11.2.js"></script>
		<script type="text/javascript" src="selectlev.js"></script>
		<link href="../../../bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<link href="offcanvas.css" rel="stylesheet">
		<link href="theme.css" rel="stylesheet">
	</head>

	<body>
		<header class="header-wrapper">
			<div class="container">
				<?php include "./include/main_nav1.php";?>
			</div>
		</header>
		<div class="col-xs-6 col-sm-3 sidebar-offcanvas" id="sidebar">
			<div class="list-group">
				<a href="quiz.html" class="list-group-item active" onclick="return link(this)">8급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">7급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">6급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">준5급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">5급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">준4급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">4급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">준3급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">3급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">2급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">1급</a>
				<a href="quiz.html" class="list-group-item" onclick="return link(this)">특급</a>
			</div>
		</div>
	</body>
</html>
