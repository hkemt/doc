<?php
include '../../dbconn/db_info.php';

$id = $_SESSION['user_id'];
$sql = "select user_num from user where user_id='".$id."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$usernum = htmlentities($row['user_num']);

$sql = "select word_lev from userselectlev where user_num='".$usernum."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$level = htmlentities($row['word_lev']);

$sql = "select count from count where user_num = '".$usernum."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$count = htmlentities($row['count']);

$sql = "select wrongstring from wrong where user_num = '".$usernum."' and word_lev='".$level."';";
$result = $conn -> query($sql);
while ($row = $result -> fetch_assoc()) {
	$numstring = $row["wrongstring"];
}

$numpieces = explode(",", $numstring);
array_shift($numpieces);

$arrnum = $numpieces;

$arrnum1 = [];

foreach ($arrnum as $value) {
	array_push($arrnum1, $value);
}
shuffle($arrnum1);

$sql = "select word_chi from word where word_num = '" . $arrnum1[$count] . "' and word_lev='".$level."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$question = htmlentities($row['word_chi']);

$sql = "select word_kor from word where word_num = '" . $arrnum1[$count] . "' and word_lev='".$level."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$answer = htmlentities($row['word_kor']);

$sql = "select word_num from word where word_num not in(" . $arrnum1[$count] . ") and word_lev='".$level."';";
$result = $conn -> query($sql);

$i = 0;
while ($row = $result -> fetch_array(MYSQLI_ASSOC)) {
	$data[$i] = $row["word_num"];
	$i++;
}

$rand_keys = array_rand($data, 3);

for ($i = 0; $i < 3; $i++) {
	$answer4[$i] = $data[$rand_keys[$i]];
}

$answer4[3] = $arrnum1[$count];

shuffle($answer4);

for ($i = 0; $i < 4; $i++) {
	$sql = "select word_kor from word where word_num = '" . $answer4[$i] . "' and word_lev='".$level."';";
	$result = $conn -> query($sql);
	$row = $result -> fetch_assoc();
	$answer4[$i] = htmlentities($row['word_kor']);
}

$quiz = array($question, $answer4[0], $answer4[1], $answer4[2], $answer4[3], $answer, count($arrnum));

$output = $quiz;
$stringJSON = json_encode($output, JSON_UNESCAPED_UNICODE);
echo urldecode($stringJSON);

$sql = "update count set count = (count + 1) where user_num = '".$usernum."';";
mysqli_query($conn, $sql);
?>