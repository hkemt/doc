var count = 0;
var score = 0;
var wrong = [];
var j = 0;
var n = 5;
var arrsize;

getquestionarray(false);

var tm = setInterval(function() {
	getquestionarray(true)
}, 5000);

var tm2 = setInterval(countDown, 1000);

function passarrsize(arg) {
	arrsize = arg;
}

function passcount(arg) {
	return $.ajax({
		type : "POST",
		url : "getcount.php",
		data : "variable1=" + arg,
		success : function() {

		}
	});
}

function getquestionarray(flagarg) {
	if (flagarg == true) {
		document.getElementById('correct').innerHTML = '오답';
		document.getElementById('correct').style.background = 'red';
	}
	count++;
	passcount(count);
	if (count == 21 || count == (arrsize + 1)) {
		location.replace('wrongfinish.php');
	}

	return $.ajax({
		type : 'POST',
		url : "wmakeonequestion.php",
		dataType : 'json',

		success : function(a) {
			answer = a[5];

			arrsize = a[6];
			passarrsize(arrsize);

			for (var i = 0; i < 5; i++) {
				document.getElementsByName("button")[i].innerHTML = a[i];
			}
			
			if(arrsize > 21) {
				document.getElementById('questionNum').innerHTML = count + "/" + "20";
			} else {
				document.getElementById('questionNum').innerHTML = count + "/" + arrsize;
			}
			
			document.getElementById('time').innerHTML = 5;
		},
		error : function() {
			location.replace('nowrong.php');
		}
		
	});
}

function correct(objButton) {
	clearInterval(tm);

	tm = setInterval(function() {
		getquestionarray(true)
	}, 5000);

	n = 7;

	countDown();

	if (objButton.innerHTML == answer) {
		document.getElementById('correct').innerHTML = '정답';
		document.getElementById('correct').style.background = 'blue'; ++score;
		if (count == 21 || count == (arrsize + 1)) {
			location.replace('wrongfinish.php');
		} else {
			getquestionarray(false);
		}
	} else {
		document.getElementById('correct').innerHTML = '오답';
		document.getElementById('correct').style.background = 'red';

		if (count == 21 || count == (arrsize + 1)) {
			location.replace('wrongfinish.php');
		} else {
			getquestionarray(false);
		}
	}
	document.getElementById('questionNum').innerHTML = count;
}

function countDown() {--n;
	if (n == 0) {
		n = 5;
	}
	document.getElementById('time').innerHTML = n;
}

function tofirst() {
	location.replace('wrongquiz.php');
}

function getout() {
	location.replace('wrongselect.php');
}