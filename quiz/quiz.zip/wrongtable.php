<?php
include '../../dbconn/db_info.php';

$id = $_SESSION['user_id'];
$sql = "select user_num from user where user_id='".$id."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$usernum = htmlentities($row['user_num']);

$sql = "select word_lev from userselectlev where user_num='".$usernum."';";
$result = $conn -> query($sql);
$row = $result -> fetch_assoc();
$level = htmlentities($row['word_lev']);

$sql = "select wrongstring from wrong where user_num = '".$usernum."' and word_lev='".$level."';";
$result = $conn -> query($sql);
while ($row = $result -> fetch_assoc()) {
	$numstring = $row["wrongstring"];
}

$numpieces = explode(",", $numstring);
array_shift($numpieces);

$arrnum = $numpieces;

$arrnum1 = [];

foreach ($arrnum as $value) {
	array_push($arrnum1, $value);
}

sort($arrnum1);

for ($i = 0; $i < count($arrnum1); $i++) {
	$sql = "select word_chi from word where word_num = '" . $arrnum1[$i] . "' and word_lev = '" . $level . "';";
	$result = $conn -> query($sql);
	$row = $result -> fetch_assoc();
	$wrongchi[$i] = htmlentities($row['word_chi']);
}

for ($i = 0; $i < count($arrnum1); $i++) {
	$sql = "select word_kor from word where word_num = '" . $arrnum1[$i] . "' and word_lev = '" . $level . "';";
	$result = $conn -> query($sql);
	$row = $result -> fetch_assoc();
	$wrongkor[$i] = htmlentities($row['word_kor']);
}

$wrong = array_merge($wrongchi, $wrongkor);

array_push($wrong, count($arrnum1));

$output = $wrong;
$stringJSON = json_encode($output, JSON_UNESCAPED_UNICODE);
echo urldecode($stringJSON);



