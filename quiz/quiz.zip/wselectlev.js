function link(Object) {
	$.ajax({
		type : "POST",
		url : "wselectlev.php",
		data : "variable1=" + Object.innerHTML,
		success : function() {
		}
	});

}
