<?php
include '../../dbconn/db_info.php';

$sql = "insert into wuserselectlev (user_num) values ('1');";
mysqli_query($conn, $sql);

$level = $_POST['variable1'];
$sql = "update wuserselectlev set word_lev='".$level."' where user_num='1';";
mysqli_query($conn, $sql);
?>