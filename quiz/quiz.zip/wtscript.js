$.ajax({
	type : 'POST',
	url : "wrongtable.php",
	dataType : 'json',

	success : function(a) {
		length = a.length;

		if (a[length-1] < 14) {
			for (var i = 0; i < a[length - 1]; i++) {
				document.getElementsByName("show1")[i].innerHTML = a[i];
			}

			for (var i = a[length - 1]; i < length-1; i++) {
				document.getElementsByName("show2")[i - a[length - 1]].innerHTML = a[i];
			}
		} else {
			for (var i = 0; i < 14; i++) {
				document.getElementsByName("show1")[i].innerHTML = a[i];
			}

			for (var i = a[length - 1]; i < a[length - 1] + 14; i++) {
				document.getElementsByName("show2")[i - a[length - 1]].innerHTML = a[i];
			}

		}

	}, error : function() {
		location.replace('nowrong.php');
	}
});

function tofirst() {
	location.replace('wrongquiz.php');
}

function getout() {
	location.replace('wrongselect.php');
}




