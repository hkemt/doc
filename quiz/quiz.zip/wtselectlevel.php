<!-- client 공통 부분(1.html앞부분, 2.main_nav스위칭부분, 3. menu_nav부분 4. 세션정보 확인부분 포함 (시작) -->
<?php include $_SERVER ['DOCUMENT_ROOT'] . "//include/common_top.php";?>

<!-- Custom styles for this template -->
<link href="/main.css" rel="stylesheet">
<script type="text/javascript" src="jquery-1.11.2.js"></script>
<script type="text/javascript" src="selectlev.js"></script>
<style>
	.g {
		font-size: 20pt;
	}
</style>

<title>Wrong Table Select Level</title>
</head>
<body>
	<header class="header-wrapper">
		<div class="container" id="main_nav1" style="display:"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/main_nav1.php";?></div>
		<div class="container" id="main_nav2" style="display: none"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/main_nav2.php";?></div>
		<?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/session_login.php";?>
		<div class="container" id="menu_nav"><?php include $_SERVER ['DOCUMENT_ROOT'] . "/include/menu_nav.php";?></div>
	</header>
<!-- client 공통 부분(1.html앞부분, 2.main_nav스위칭부분, 3. menu_nav부분 4. 세션정보 확인부분 포함 (끝) -->

	<section class="container margin_top">
		<section id="main_menu" class="row ab">
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">8급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">7급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">6급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">준5급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">5급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">준4급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">4급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">준3급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">3급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">2급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">1급</a>
					</div>
				</div>
			</div>
			
			<div class="col-md-4 col-sm-6">
				<div class="thumbnail dropdown border">
					<div class="tc g">
						<a href="wrongtable1.php" onclick="return link(this)">특급</a>
					</div>
				</div>
			</div>
		</section>
	</section>
	</body>
	</html>
