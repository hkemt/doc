package emt.emt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import emt.emt.dao.UserDaoImpl;
import emt.emt.domain.User;

@Service
public class UserServiceImpl implements UserService{
	@Autowired UserDaoImpl userDao;
	
	@Override
	public User loginCheck(User user) {
		return userDao.loginCheck(user);
	}
}
